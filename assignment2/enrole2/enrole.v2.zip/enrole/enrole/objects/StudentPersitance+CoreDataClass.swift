//
//  StudentPersitance+CoreDataClass.swift
//  enrole
//
//  Created by Manogna Podishetty on 10/15/19.
//  Copyright © 2019 manogna podishetty. All rights reserved.
//
//

import Foundation
import CoreData


public class StudentPersitance: NSManagedObject {

}
