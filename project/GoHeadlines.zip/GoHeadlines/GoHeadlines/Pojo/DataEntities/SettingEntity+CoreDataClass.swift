//
//  SettingEntity+CoreDataClass.swift
//  GoHeadlines
//
//  Created by Manogna podishetty on 12/10/19.
//  Copyright © 2019 Manogna podishetty. All rights reserved.
//
//

import Foundation
import CoreData


public class SettingEntity: NSManagedObject {

}
