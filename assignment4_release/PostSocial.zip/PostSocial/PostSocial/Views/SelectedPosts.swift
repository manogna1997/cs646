//
//  SelectedPosts.swift
//  PostSocial
//
//  Created by Abhilash Keerthi on 11/17/19.
//  Copyright © 2019 Manogna podishetty. All rights reserved.
//

import SwiftUI

struct PostsView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct PostsView_Previews: PreviewProvider {
    static var previews: some View {
        PostsView()
    }
}
