//
//  UserPosts.swift
//  PostSocial
//
//  Created by Abhilash Keerthi on 11/10/19.
//  Copyright © 2019 Manogna podishetty. All rights reserved.
//

import SwiftUI

struct UserPosts: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct UserPosts_Previews: PreviewProvider {
    static var previews: some View {
        UserPosts()
    }
}
